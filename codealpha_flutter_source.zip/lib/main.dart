import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const CodeAlphaApp());

const ink = Color(0xFF17251E);
const forest = Color(0xFF246B4B);
const mint = Color(0xFFE7F3EB);
const canvas = Color(0xFFF7F8F4);

class CodeAlphaApp extends StatelessWidget {
  const CodeAlphaApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'CodeAlpha Studio',
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: canvas,
      colorScheme: ColorScheme.fromSeed(seedColor: forest, surface: canvas),
      appBarTheme: const AppBarTheme(
        backgroundColor: canvas,
        foregroundColor: ink,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
      ),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selected = 0;
  final pages = const [FlashcardsPage(), QuotesPage(), FitnessPage()];
  final titles = const ['Flashcards', 'Daily quotes', 'Fitness tracker'];
  final icons = const [
    Icons.style_rounded,
    Icons.format_quote_rounded,
    Icons.directions_run_rounded,
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      titleSpacing: 22,
      title: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: forest,
              borderRadius: BorderRadius.circular(13),
            ),
            child: const Icon(Icons.bolt_rounded, color: Colors.white),
          ),
          const SizedBox(width: 11),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'CodeAlpha',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
              ),
              Text(
                titles[selected],
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ],
          ),
        ],
      ),
    ),
    body: SafeArea(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 880),
          child: pages[selected],
        ),
      ),
    ),
    bottomNavigationBar: NavigationBar(
      selectedIndex: selected,
      onDestinationSelected: (i) => setState(() => selected = i),
      destinations: [
        for (var i = 0; i < titles.length; i++)
          NavigationDestination(icon: Icon(icons[i]), label: titles[i]),
      ],
    ),
  );
}

class StudyCard {
  StudyCard(this.question, this.answer);
  String question;
  String answer;
  Map<String, dynamic> toJson() => {'question': question, 'answer': answer};
  factory StudyCard.fromJson(Map<String, dynamic> json) =>
      StudyCard(json['question'] as String, json['answer'] as String);
}

class FlashcardsPage extends StatefulWidget {
  const FlashcardsPage({super.key});
  @override
  State<FlashcardsPage> createState() => _FlashcardsPageState();
}

class _FlashcardsPageState extends State<FlashcardsPage> {
  final cards = <StudyCard>[
    StudyCard(
      'What does Flutter use to build its UI?',
      'Widgets: composable building blocks for every part of the interface.',
    ),
    StudyCard(
      'What is a Dart Future?',
      'An object that represents a result that will be available later.',
    ),
    StudyCard(
      'What does setState do?',
      'It tells Flutter to rebuild this part of the widget tree with updated state.',
    ),
  ];
  int index = 0;
  bool showingAnswer = false;
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('study_cards');
    if (raw != null) {
      final decoded = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
      if (mounted)
        setState(() {
          cards
            ..clear()
            ..addAll(decoded.map(StudyCard.fromJson));
          loaded = true;
        });
    } else if (mounted)
      setState(() => loaded = true);
  }

  Future<void> _save() async =>
      (await SharedPreferences.getInstance()).setString(
        'study_cards',
        jsonEncode(cards.map((c) => c.toJson()).toList()),
      );

  Future<void> _edit({StudyCard? card}) async {
    final question = TextEditingController(text: card?.question ?? '');
    final answer = TextEditingController(text: card?.answer ?? '');
    final result = await showDialog<StudyCard>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(card == null ? 'Add a flashcard' : 'Edit flashcard'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: question,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Question'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: answer,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Answer'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (question.text.trim().isNotEmpty &&
                  answer.text.trim().isNotEmpty)
                Navigator.pop(
                  context,
                  StudyCard(question.text.trim(), answer.text.trim()),
                );
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (result == null) return;
    setState(() {
      if (card == null) {
        cards.add(result);
        index = cards.length - 1;
      } else {
        card.question = result.question;
        card.answer = result.answer;
      }
      showingAnswer = false;
    });
    await _save();
  }

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(22, 16, 22, 28),
    children: [
      const Eyebrow('STUDY DECK'),
      const SizedBox(height: 8),
      const Text(
        'Learn one card at a time.',
        style: TextStyle(color: ink, fontSize: 25, fontWeight: FontWeight.w800),
      ),
      const SizedBox(height: 6),
      Text(
        '${cards.length} cards in your personal deck',
        style: const TextStyle(color: Colors.black54),
      ),
      const SizedBox(height: 20),
      if (loaded && cards.isNotEmpty) ...[
        Card(
          elevation: 0,
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(26),
          ),
          child: Padding(
            padding: const EdgeInsets.all(25),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'CARD ${index + 1} / ${cards.length}',
                      style: const TextStyle(
                        color: forest,
                        letterSpacing: 1.1,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    IconButton(
                      onPressed: () => _edit(card: cards[index]),
                      icon: const Icon(Icons.edit_outlined),
                    ),
                  ],
                ),
                const SizedBox(height: 19),
                Text(
                  showingAnswer ? cards[index].answer : cards[index].question,
                  style: const TextStyle(
                    fontSize: 23,
                    height: 1.4,
                    fontWeight: FontWeight.w700,
                    color: ink,
                  ),
                ),
                const SizedBox(height: 25),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () =>
                        setState(() => showingAnswer = !showingAnswer),
                    icon: Icon(
                      showingAnswer
                          ? Icons.visibility_off_outlined
                          : Icons.visibility_outlined,
                    ),
                    label: Text(
                      showingAnswer ? 'Show question' : 'Show answer',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => setState(() {
                  index = (index - 1 + cards.length) % cards.length;
                  showingAnswer = false;
                }),
                icon: const Icon(Icons.arrow_back_rounded),
                label: const Text('Previous'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => setState(() {
                  index = (index + 1) % cards.length;
                  showingAnswer = false;
                }),
                icon: const Icon(Icons.arrow_forward_rounded),
                label: const Text('Next'),
              ),
            ),
          ],
        ),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton.icon(
            onPressed: () async {
              setState(() {
                cards.removeAt(index);
                if (cards.isNotEmpty) index %= cards.length;
                showingAnswer = false;
              });
              await _save();
            },
            icon: const Icon(Icons.delete_outline),
            label: const Text('Delete card'),
          ),
        ),
      ] else if (loaded)
        EmptyState(
          icon: Icons.style_rounded,
          title: 'Your deck is clear',
          detail: 'Add a question and answer to start studying.',
        ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        onPressed: () => _edit(),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add flashcard'),
      ),
    ],
  );
}

class QuotesPage extends StatefulWidget {
  const QuotesPage({super.key});
  @override
  State<QuotesPage> createState() => _QuotesPageState();
}

class _QuotesPageState extends State<QuotesPage> {
  static const quotes = [
    ('It always seems impossible until it is done.', 'Nelson Mandela'),
    (
      'Great things are done by a series of small things brought together.',
      'Vincent van Gogh',
    ),
    ('The secret of getting ahead is getting started.', 'Mark Twain'),
    ('Believe you can and you are halfway there.', 'Theodore Roosevelt'),
    ('Well done is better than well said.', 'Benjamin Franklin'),
    ('Act as if what you do makes a difference. It does.', 'William James'),
    ('The future depends on what you do today.', 'Mahatma Gandhi'),
  ];
  int current = DateTime.now().day % quotes.length;
  int previous = -1;
  bool favorite = false;
  void next() => setState(() {
    previous = current;
    current =
        (current + 1 + DateTime.now().second % (quotes.length - 1)) %
        quotes.length;
    if (current == previous) current = (current + 1) % quotes.length;
    favorite = false;
  });

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(22, 16, 22, 28),
    children: [
      const Eyebrow('A LITTLE INSPIRATION'),
      const SizedBox(height: 8),
      const Text(
        'A thought for today.',
        style: TextStyle(color: ink, fontSize: 25, fontWeight: FontWeight.w800),
      ),
      const SizedBox(height: 22),
      Container(
        padding: const EdgeInsets.all(27),
        decoration: BoxDecoration(
          color: forest,
          borderRadius: BorderRadius.circular(28),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(
              Icons.format_quote_rounded,
              color: Color(0xFFB8E2C7),
              size: 38,
            ),
            const SizedBox(height: 18),
            Text(
              '“${quotes[current].$1}”',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 27,
                height: 1.38,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 21),
            Text(
              '— ${quotes[current].$2}',
              style: const TextStyle(color: Color(0xFFD2EBDD), fontSize: 15),
            ),
            const SizedBox(height: 26),
            Row(
              children: [
                IconButton.filledTonal(
                  onPressed: () => setState(() => favorite = !favorite),
                  icon: Icon(
                    favorite
                        ? Icons.favorite_rounded
                        : Icons.favorite_border_rounded,
                  ),
                ),
                const Spacer(),
                FilledButton.tonalIcon(
                  onPressed: next,
                  icon: const Icon(Icons.autorenew_rounded),
                  label: const Text('New quote'),
                ),
              ],
            ),
          ],
        ),
      ),
      const SizedBox(height: 17),
      const Text(
        'A fresh quote is ready each time you return.',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.black54),
      ),
    ],
  );
}

class Activity {
  Activity(this.name, this.minutes, this.calories, this.date);
  String name;
  int minutes;
  int calories;
  DateTime date;
  Map<String, dynamic> toJson() => {
    'name': name,
    'minutes': minutes,
    'calories': calories,
    'date': date.toIso8601String(),
  };
  factory Activity.fromJson(Map<String, dynamic> json) => Activity(
    json['name'],
    json['minutes'],
    json['calories'],
    DateTime.parse(json['date']),
  );
}

class FitnessPage extends StatefulWidget {
  const FitnessPage({super.key});
  @override
  State<FitnessPage> createState() => _FitnessPageState();
}

class _FitnessPageState extends State<FitnessPage> {
  final logs = <Activity>[];
  int steps = 0;
  bool loaded = false;
  DateTime get today => DateTime.now();
  bool isToday(DateTime date) =>
      date.year == today.year &&
      date.month == today.month &&
      date.day == today.day;
  List<Activity> get todays => logs.where((a) => isToday(a.date)).toList();
  List<Activity> get thisWeek => logs
      .where(
        (a) => today.difference(a.date).inDays < 7 && !a.date.isAfter(today),
      )
      .toList();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('fitness_activities');
    if (raw != null)
      logs.addAll((jsonDecode(raw) as List).map((e) => Activity.fromJson(e)));
    if (mounted)
      setState(() {
        steps =
            p.getInt('steps_${today.year}_${today.month}_${today.day}') ?? 0;
        loaded = true;
      });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
      'fitness_activities',
      jsonEncode(logs.map((a) => a.toJson()).toList()),
    );
    await p.setInt('steps_${today.year}_${today.month}_${today.day}', steps);
  }

  Future<void> _editSteps() async {
    final c = TextEditingController(text: steps.toString());
    final value = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Update today’s steps'),
        content: TextField(
          controller: c,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Steps'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, int.tryParse(c.text)),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (value != null && value >= 0) {
      setState(() => steps = value);
      await _save();
    }
  }

  Future<void> _addActivity() async {
    final name = TextEditingController();
    final minutes = TextEditingController();
    final calories = TextEditingController();
    final result = await showDialog<Activity>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Log a workout'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: name,
              autofocus: true,
              decoration: const InputDecoration(
                labelText: 'Exercise type',
                hintText: 'e.g. Walk, cycling',
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: minutes,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Minutes'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: calories,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Calories'),
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final m = int.tryParse(minutes.text);
              final k = int.tryParse(calories.text);
              if (name.text.trim().isNotEmpty && m != null && k != null)
                Navigator.pop(
                  ctx,
                  Activity(name.text.trim(), m, k, DateTime.now()),
                );
            },
            child: const Text('Add activity'),
          ),
        ],
      ),
    );
    if (result != null) {
      setState(() => logs.insert(0, result));
      await _save();
    }
  }

  @override
  Widget build(BuildContext context) {
    final mins = todays.fold<int>(0, (sum, a) => sum + a.minutes);
    final kcal = todays.fold<int>(0, (sum, a) => sum + a.calories);
    final weekly = List<int>.generate(7, (i) {
      final d = DateTime(
        today.year,
        today.month,
        today.day,
      ).subtract(Duration(days: 6 - i));
      return logs
          .where(
            (a) =>
                a.date.year == d.year &&
                a.date.month == d.month &&
                a.date.day == d.day,
          )
          .fold<int>(0, (s, a) => s + a.minutes);
    });
    return ListView(
      padding: const EdgeInsets.fromLTRB(22, 16, 22, 28),
      children: [
        const Eyebrow('YOUR MOVEMENT, YOUR WAY'),
        const SizedBox(height: 8),
        const Text(
          'Show up for yourself.',
          style: TextStyle(
            color: ink,
            fontSize: 25,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          DateFormatLabel(today),
          style: const TextStyle(color: Colors.black54),
        ),
        const SizedBox(height: 19),
        Row(
          children: [
            Expanded(
              child: _MetricCard(
                label: 'Steps',
                value: '$steps',
                icon: Icons.directions_walk_rounded,
                onTap: _editSteps,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _MetricCard(
                label: 'Active min',
                value: '$mins',
                icon: Icons.timer_outlined,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _MetricCard(
                label: 'Calories',
                value: '$kcal',
                icon: Icons.local_fire_department_outlined,
              ),
            ),
          ],
        ),
        const SizedBox(height: 13),
        Card(
          elevation: 0,
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(23),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'This week',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Workout minutes by day',
                  style: TextStyle(color: Colors.black54, fontSize: 12),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 120,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      for (var i = 0; i < 7; i++)
                        _DayBar(
                          minutes: weekly[i],
                          label:
                              ['M', 'T', 'W', 'T', 'F', 'S', 'S'][DateTime(
                                    today.year,
                                    today.month,
                                    today.day,
                                  ).subtract(Duration(days: 6 - i)).weekday -
                                  1],
                          active: i == 6,
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Activity log',
              style: TextStyle(
                color: ink,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            TextButton.icon(
              onPressed: _addActivity,
              icon: const Icon(Icons.add),
              label: const Text('Log workout'),
            ),
          ],
        ),
        if (loaded && todays.isEmpty)
          const EmptyState(
            icon: Icons.spa_outlined,
            title: 'Your day starts here',
            detail: 'Log a workout to see your progress.',
          ),
        for (final activity in todays)
          Card(
            elevation: 0,
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(17),
            ),
            child: ListTile(
              leading: const CircleAvatar(
                backgroundColor: mint,
                child: Icon(Icons.fitness_center_rounded, color: forest),
              ),
              title: Text(
                activity.name,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              subtitle: Text(
                '${activity.minutes} min · ${activity.calories} kcal',
              ),
              trailing: IconButton(
                tooltip: 'Delete activity',
                onPressed: () async {
                  setState(() => logs.remove(activity));
                  await _save();
                },
                icon: const Icon(Icons.delete_outline),
              ),
            ),
          ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.label,
    required this.value,
    required this.icon,
    this.onTap,
  });
  final String label, value;
  final IconData icon;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(21),
    child: Ink(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(21),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: forest),
          const SizedBox(height: 12),
          Text(
            value,
            style: const TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.w800,
              color: ink,
            ),
          ),
          Text(
            label,
            style: const TextStyle(fontSize: 11, color: Colors.black54),
          ),
        ],
      ),
    ),
  );
}

class _DayBar extends StatelessWidget {
  const _DayBar({
    required this.minutes,
    required this.label,
    required this.active,
  });
  final int minutes;
  final String label;
  final bool active;
  @override
  Widget build(BuildContext context) => Column(
    mainAxisAlignment: MainAxisAlignment.end,
    children: [
      Container(
        width: 25,
        height: minutes == 0 ? 7 : (minutes.clamp(1, 100) * .68 + 9),
        decoration: BoxDecoration(
          color: active ? forest : const Color(0xFFBFD9C8),
          borderRadius: BorderRadius.circular(9),
        ),
      ),
      const SizedBox(height: 7),
      Text(label, style: const TextStyle(fontSize: 10, color: Colors.black54)),
    ],
  );
}

class Eyebrow extends StatelessWidget {
  const Eyebrow(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Text(
    text,
    style: const TextStyle(
      color: forest,
      fontSize: 10,
      letterSpacing: 1.3,
      fontWeight: FontWeight.w800,
    ),
  );
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    required this.icon,
    required this.title,
    required this.detail,
    super.key,
  });
  final IconData icon;
  final String title, detail;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 28),
    child: Column(
      children: [
        Icon(icon, color: forest, size: 32),
        const SizedBox(height: 9),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(
          detail,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.black54),
        ),
      ],
    ),
  );
}

String DateFormatLabel(DateTime date) {
  const weekdays = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];
  const months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  return '${weekdays[date.weekday - 1]}, ${months[date.month - 1]} ${date.day}';
}
