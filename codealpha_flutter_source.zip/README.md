# CodeAlpha Flutter Apps

One Flutter app with three task screens, written in Dart:

- **Flashcards:** flip to reveal answers, move through the deck, add/edit/delete cards. The deck is saved on device with `shared_preferences`.
- **Random quotes:** see an initial quote and tap **New quote** to pick another; each quote includes its author.
- **Fitness tracker:** log steps and workouts, review daily totals and a seven-day workout chart, and remove activity entries. Records are saved locally with `shared_preferences`.

## Run

Install Flutter, then from this folder run:

```sh
flutter pub get
flutter run
```

The generated Android and web runners are included. To launch the browser version, run `flutter run -d chrome`.
