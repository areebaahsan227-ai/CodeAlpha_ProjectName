package com.example.codealpha_apps

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
